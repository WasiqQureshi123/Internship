import 'package:flutter/material.dart';

class CounterPage extends StatefulWidget {
  const CounterPage({super.key});

  @override
  State<CounterPage> createState() => _CounterPageState();
}

class _CounterPageState extends State<CounterPage> {
  // ignore: unused_field
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  void _decrementCounter() {
    setState(() {
      _counter--;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text('Simple Counter App')),
        backgroundColor: Colors.blueGrey,
      ),
      body: Center(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 50,
            width: 300,
            decoration: BoxDecoration(
              color: Colors.blueGrey,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
              child: Text(
                'Counter Value:',
                style: TextStyle(
                  fontSize: 20,
                  backgroundColor: Colors.blueGrey,
                ),
              ),
            ),
          ),
          Text(
            '$_counter',
            style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 40,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              FloatingActionButton(
                backgroundColor: Colors.grey,
                onPressed: () {
                  _incrementCounter();
                },
                child: Text('+'),
              ),
              SizedBox(
                width: 20,
              ),
              FloatingActionButton(
                backgroundColor: Colors.grey,
                onPressed: () {
                  _decrementCounter();
                },
                child: Text('-'),
              ),
            ],
          ),
        ],
      )),
    );
  }
}
