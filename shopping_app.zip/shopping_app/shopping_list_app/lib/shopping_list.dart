import 'package:flutter/material.dart';

class ShoppingList extends StatefulWidget {
  const ShoppingList({super.key});

  @override
  State<ShoppingList> createState() => _ShoppingListState();
}

class _ShoppingListState extends State<ShoppingList> {
  final List<String> _shoppingList = [];
  final TextEditingController _controller = TextEditingController();

  void _addItem() {
    setState(() {
      if (_controller.text.isNotEmpty) {
        _shoppingList.add(_controller.text);
        _controller.clear();
      }
    });
  }

  void _removeItem(int index) {
    setState(() {
      _shoppingList.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
            child: Text(
          'Shopping List',
          style: TextStyle(
              fontSize: 22, fontWeight: FontWeight.w600, color: Colors.white),
        )),
        backgroundColor: Colors.deepPurple,
        elevation: 10,
        actions: [
          IconButton(onPressed: () {}, icon: Icon(Icons.shopping_cart))
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: const InputDecoration(
                          hintText: 'Add a new item',
                          hintStyle: TextStyle(color: Colors.grey),
                          border: InputBorder.none),
                      style: TextStyle(fontSize: 18),
                    ),
                  ),
                  ElevatedButton(
                      onPressed: _addItem,
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.deepPurple,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          )),
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16),
                        child: Text(
                          'Add',
                          style: TextStyle(fontSize: 16, color: Colors.white),
                        ),
                      )),
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Expanded(
              child: _shoppingList.isEmpty
                  ? Center(
                      child: Text(
                        'No items added yet!',
                        style: TextStyle(
                            fontSize: 18,
                            color: Colors.grey[600],
                            fontWeight: FontWeight.w500),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _shoppingList.length,
                      itemBuilder: (context, index) {
                        return Dismissible(
                          key: Key(_shoppingList[index]),
                          onDismissed: (direction) {
                            _removeItem(index);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Item removed'),
                                duration: Duration(seconds: 1),
                              ),
                            );
                          },
                          background: Container(
                              color: Colors.red,
                              alignment: Alignment.centerRight,
                              padding: EdgeInsets.symmetric(horizontal: 20),
                              child: Icon(Icons.delete,
                                  color: Colors.white, size: 30)),
                          child: Card(
                            margin: EdgeInsets.symmetric(
                                vertical: 5, horizontal: 10),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                            elevation: 4,
                            child: ListTile(
                              contentPadding: EdgeInsets.all(16),
                              title: Text(
                                _shoppingList[index],
                                style: TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.w500),
                              ),
                              trailing: Icon(
                                Icons.shopping_bag,
                                color: Colors.deepPurple,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
