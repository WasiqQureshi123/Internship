package com.example.shopping_list_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
