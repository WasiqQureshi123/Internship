import 'package:flutter/material.dart';
import 'package:quiz_app/resultscreen.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int _currentQuestionIndex = 0;
  int _score = 0;
  List<int> _selectedAnswer = [];
  final List<Map<String, Object>> _questions = [
    {
      'question': 'What is the capital of Pakistan',
      'answer': ['Islamabad', 'Delhi', 'Karachi', 'Paris'],
      'correctAnswer': 0
    },
    {
      'question': 'What is String?',
      'answer': ['DataType', 'Function', 'Program'],
      'correctAnswer': 0
    }
  ];

  void _answerQuestion(int index) {
    setState(() {
      _selectedAnswer.add(index);
      if (index == _questions[_currentQuestionIndex]['correctAnswer']) {
        _score++;
      }
      if (_currentQuestionIndex < _questions.length - 1) {
        _currentQuestionIndex++;
      } else {
        _showResults(context);
      }
    });
  }

  void _showResults(BuildContext context) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => ResultScreen(
                  selectedAnswer: _selectedAnswer,
                  score: _score,
                  totalQuestions: _questions.length,
                )));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        title: Center(
          child: Text(
            'Quiz App',
            style: TextStyle(
                fontSize: 35, fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ),
        backgroundColor: Colors.indigo,
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            LinearProgressIndicator(
              value: (_currentQuestionIndex + 1) / _questions.length,
              backgroundColor: Colors.white,
              color: Colors.indigo,
            ),
            SizedBox(height: 20),
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  _questions[_currentQuestionIndex]['question'] as String,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
            SizedBox(height: 20),
            Expanded(
                child: ListView(
              children: (_questions[_currentQuestionIndex]['answer']
                      as List<String>) // Correct key here
                  .asMap()
                  .entries
                  .map(
                    (entry) => Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30)),
                          backgroundColor: Colors.indigo,
                        ),
                        onPressed: () => _answerQuestion(entry.key),
                        child: Text(
                          entry.value,
                          style: TextStyle(fontSize: 18, color: Colors.white),
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ))
          ],
        ),
      ),
    );
  }
}
